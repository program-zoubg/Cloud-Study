import socketserver
import os
import json
from datetime import *
import time as t
import random


class RequestHandle(socketserver.BaseRequestHandler):
    def handle(self):
        print(self.request)
        print(self.client_address)

        print(self.request.send('//start//'.encode('utf-8').zfill(128)))
        while True:
            data = self.request.recv(128)
            data = data.decode('utf-8')
            if 'get' in data:
                len_get = bytes(str(len(os.listdir('apps/'))), 'utf-8').zfill(2)
                print(self.request.send(len_get))
                for i in os.listdir('apps/'):
                    title = i.strip('.py')
                    note = open('apps/' + i, 'r', encoding='utf-8').readlines()[0].strip('\n')
                    title = ' '.join(title.split('%20'))
                    header = {
                        'file_name': title,
                        'file_type': i.split('.')[-1],
                        'file_note': note,
                        'file_size': str(os.path.getsize('apps/' + i))
                    }
                    header_json = json.dumps(header)
                    header_bytes = header_json.encode('utf-8')
                    header_h = bytes(str(len(header_bytes)), 'gbk').zfill(4)
                    print(self.request.send(header_h))
                    print(self.request.send(header_bytes))
            if 'app' in data:
                get_f = '%20'.join((data.split('//')[-1]).split())
                self.request.send(str(os.path.getsize('apps/' + get_f)).encode('gbk').zfill(32))
                self.request.send(open('apps/' + get_f, 'r', encoding='utf-8').read().encode('utf-8'))
            if 'time' in data:
                times = str(datetime.now())
                self.request.send(times.encode('utf-8').zfill(1024))
            if 'user' in data:
                uid = data.split('?')[1]
                pwd = data.split('?')[2]
                try:
                    with open('ServerData/Users/' + uid + '/PassWord.ini', 'r', encoding='utf-8') as user:
                        uok = user.read() == pwd
                    if uok:
                        self.request.send('1'.encode('gbk').zfill(1))
                        with open('ServerData/Users/' + uid + '/Name.ini', 'r', encoding='utf-8') as un:
                            user_name = un.read()
                            self.request.send(user_name.encode('utf-8').zfill(256))
                    else:
                        self.request.send('0'.encode('gbk').zfill(1))
                except FileNotFoundError:
                    self.request.send('2'.encode('gbk').zfill(1))  # 2: 没有账号异常代码
            if 'sign_in' in data:
                random_uid = str(int(t.time())) + str(random.randint(10000, 99999))
                sign_id = data.split('&')[1]
                sign_pwd = data.split('&')[2]
                try:
                    os.makedirs('ServerData/Users/' + random_uid)
                    with open('ServerData/Users/' + random_uid + '/Name.ini', 'w', encoding='utf-8') as u_name:
                        u_name.write(sign_id)
                    with open('ServerData/Users/' + random_uid + '/PassWord.ini', 'w', encoding='utf-8') as u_pwd:
                        u_pwd.write(sign_pwd)
                    self.request.send(random_uid.encode('gbk').zfill(128))
                except Exception:
                    pass
            if 'xg_pwd' in data:
                xg_id = data.split('@')[1]
                xg_pwd = data.split('@')[2]
                try:
                    with open('ServerData/Users/' + xg_id + '/PassWord.ini', 'w', encoding='utf-8') as xg:
                        xg.write(xg_pwd)
                    self.request.send('1'.encode('gbk').zfill(1))
                except Exception:
                    self.request.send('0'.encode('gbk').zfill(1))


print('version 1.0.0-------------------')
sk = socketserver.ThreadingTCPServer(('0.0.0.0', 8080), RequestHandle)
sk.serve_forever()
