"""Cloud Start 提供的ChatGPT SDK API接口"""

import tkinter


def get_gpt():
    input_get = input_var.get()
    return input_get


main = tkinter.Tk()

lab = tkinter.Label(main, text='请输入要询问的问题（输入quit结束对话）>>> ')
lab.pack()

try:
    import requests
    import json
    import platform

    input_var = tkinter.Entry(main, width=80)
    input_var.pack()


    def gpt():
        input_str = get_gpt()

        if input_str == 'quit':
            exit(0)

        url = "https://api.fystart.cn/gpt?message=" + input_str

        response = requests.get(url)
        data = json.loads(response.text)

        try:
            i = data['message']
        except Exception:
            i = 'Sorry! 我可能出现了一些问题！请尝试联系开发者'

        res = tkinter.Label(main, text=i)
        res.pack()


    btn_ok = tkinter.Button(main, text='确定', command=gpt)
    btn_ok.pack()

except Exception as e:
    print('我们出现了一点问题！')
    print(e)

main.mainloop()
