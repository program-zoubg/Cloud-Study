"""手机号信息查询"""


def get_entry():
    url = 'https://api.vvhan.com/api/phone?tel=' + tel.get()
    header = {'user-agent': 'Content-Type:text/json;charset=UTF-8;'}
    response = requests.get(url, headers=header)
    info_d = json.loads(response.text)
    return info_d


def get():
    global info
    global info_string
    info_string = ''
    info = get_entry()
    info_string += '可用：'
    if info['success']:
        info_string += '是\n'
        info_string += '所在地址：' + info['info']['local'] + '\n'
        info_string += '段：' + info['info']['duan'] + '\n'
        info_string += '类型：' + info['info']['type'] + '\n'
        info_string += '运营商：' + info['info']['yys'] + '\n'
        info_string += '标准：' + info['info']['bz'] + '\n'
    else:
        info_string += '否\n'

    info_lab['text'] = info_string
    print(info_string)


import json
import requests
import tkinter


info = dict()
window = tkinter.Tk()

window.title('手机号信息')
window.geometry('500x300')

tel = tkinter.Entry(window, width=45)
tel.pack()
tel.place(rely=0.2, relx=0.15)

lab = tkinter.Label(window, text='手机号：')
lab.pack()
lab.place(rely=0.2, relx=0)

ok_btn = tkinter.Button(window, text='确定', command=get)
ok_btn.pack()
ok_btn.place(rely=0.4, relx=0.45)

info_lab = tkinter.Label(window)
info_lab.pack()
info_lab.place(rely=0.5, relx=0)

info_string = ''

window.mainloop()
