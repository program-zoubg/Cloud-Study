"""云便签"""

import socket
from tkinter import *

sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sk.connect(('127.0.0.1', 8080))

main = Tk()

main.mainloop()
