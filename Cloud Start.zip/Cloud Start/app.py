import socket
from tkinter import *
from tkinter import messagebox
import datetime
import json
import importlib
from threading import Thread
import os


def sz_command():
    sz_main = Tk()
    sz_main.title('设置')
    sz_main.geometry('500x100+100+100')

    def enter_input():
        ip_text = sz_input.get()
        open('db/server.ini', 'w', encoding='utf-8').write(ip_text)
        messagebox.showinfo('成功', 'OK! 设置成功，服务器ip为' + ip_text + '。重启Cloud Start后生效！')

    sz_lab = Label(sz_main, text='Server服务器ip：', bg='white', font=('PingFangSC-Regular', 12), width=0)
    sz_lab.pack()
    sz_lab.place(x=10, y=0)
    sz_input = Entry(sz_main, width=30)
    sz_input.pack()
    sz_p = Button(sz_main, text='确定', width=10, height=2, command=enter_input)
    sz_p.pack()

    sz_main.mainloop()


def yysd_command():
    def use():
        input_app = app_entry.get()
        sk.send(bytes('app//' + input_app + '.py', 'utf-8').zfill(128))
        headers = sk.recv(32).decode('gbk')
        file_w = sk.recv(int(headers)).decode('utf-8')
        open(f'Application/{input_app}.py', 'w', encoding='utf-8').write(file_w)

    sk.send(bytes('get', 'utf-8').zfill(128))
    messagebox.showinfo('等待', '加载中...')
    yysd_main = Tk()
    yysd_main.title('应用商店')
    yysd_main.geometry('970x700+100+100')
    get_lens = int(sk.recv(2).decode('utf-8'))
    x = y = 10
    for i in range(get_lens):
        head_h = int(sk.recv(4).decode('gbk'))
        header = sk.recv(head_h).decode('utf-8')
        header = json.loads(header)

        lab_file = Label(yysd_main, text=header['file_name'] + '\n\n' + header['file_note'].strip('"""'), width=30,
                         height=8, bg='gray')
        lab_file.pack()
        lab_file.place(x=x, y=y)
        x += 320
        if x >= 960:
            y += 180
            x = 10

    app_entry = Entry(yysd_main, width=95)
    app_entry.pack()
    app_entry.place(relx=0.01, rely=0.90)

    app_ok = Button(yysd_main, text='安装', width=8, command=use)
    app_ok.pack()
    app_ok.place(relx=0.92, rely=0.905)

    yysd_main.mainloop()


def wd_command():
    def sign_in():
        def sign_in_cmd():
            sign_idn = sign_entry.get().encode('utf-8')
            sign_pwd_n = sign_pwd.get().encode('utf-8')
            sk.send(('sign_in&'.encode('utf-8') + sign_idn + '&'.encode('utf-8') + sign_pwd_n).zfill(128))
            sign_uid = sk.recv(128).decode('gbk').strip('0')
            messagebox.showinfo('您的UID', '您的UID：' + sign_uid)

        sign_main = Tk()

        sign_main.title('注册新账户')
        sign_main.geometry('400x150+200+200')

        sign_id = Label(sign_main, text='ID昵称:')
        sign_id.pack()
        sign_id.place(x=0, y=6)

        sign_entry = Entry(sign_main, width=30)
        sign_entry.pack()
        sign_entry.place(x=75, y=5)

        sign_pwd = Label(sign_main, text='注册密码:')
        sign_pwd.pack()
        sign_pwd.place(x=0, y=46)

        sign_pwd = Entry(sign_main, width=30, show='*')
        sign_pwd.pack()
        sign_pwd.place(x=75, y=45)

        sign_btn = Button(sign_main, width=15, height=3, text='注册', command=sign_in_cmd)
        sign_btn.pack()
        sign_btn.place(relx=0.32, rely=0.6)

        sign_main.mainloop()

    def xg_pwd():
        def xg_pwd_cmd():
            uid = xg_entry.get().encode('utf-8')
            jiu_pwd = entry_jiu_pwd.get().encode('utf-8')
            xin_pwd = entry_pwd.get().encode('utf-8')
            sk.send(('user?'.encode('utf-8') + uid + '?'.encode('utf-8') + jiu_pwd).zfill(128))
            uok = int(sk.recv(1).decode('gbk'))
            if uok == 1 or uok == 0:
                if uok == 1:
                    sk.recv(256).decode('utf-8').strip('0')
                    sk.send(('xg_pwd@'.encode('utf-8') + uid + '@'.encode('utf-8') + xin_pwd).zfill(128))
                    is_xg_ok = bool(int(sk.recv(1).decode('gbk')))
                    if is_xg_ok:
                        messagebox.showinfo('修改密码', '修改成功！')
                    else:
                        messagebox.showinfo('修改密码', '我们好似遇到的一些问题...')
                if uok == 0:
                    messagebox.showinfo('验证', '验证失败！旧密码错误！')
            elif uok == 2:
                messagebox.showinfo('异常', '账号不存在！')

        xg_main = Tk()

        xg_main.title('忘记密码')
        xg_main.geometry('400x200+200+200')

        xg_id = Label(xg_main, text='UID:')
        xg_id.pack()
        xg_id.place(x=0, y=6)

        xg_entry = Entry(xg_main, width=30)
        xg_entry.pack()
        xg_entry.place(x=75, y=5)

        xg_pwd_pwd = Label(xg_main, text='旧密码:')
        xg_pwd_pwd.pack()
        xg_pwd_pwd.place(x=0, y=46)

        entry_jiu_pwd = Entry(xg_main, width=30, show='*')
        entry_jiu_pwd.pack()
        entry_jiu_pwd.place(x=75, y=45)

        xg_xin_pwd = Label(xg_main, text='新密码:')
        xg_xin_pwd.pack()
        xg_xin_pwd.place(x=0, y=86)

        entry_pwd = Entry(xg_main, width=30, show='*')
        entry_pwd.pack()
        entry_pwd.place(x=75, y=85)

        xg_pwd_btn = Button(xg_main, width=15, height=3, text='修改密码', command=xg_pwd_cmd)
        xg_pwd_btn.pack()
        xg_pwd_btn.place(relx=0.32, rely=0.6)

        xg_main.mainloop()

    wd_main = Tk()

    wd_main.title('我的')
    wd_main.geometry('750x500+100+100')

    sign_in_btn = Button(wd_main, text='注册新账号', width=8, height=2, command=sign_in)
    sign_in_btn.pack()
    sign_in_btn.place(relx=0.15, rely=0.85)

    xg_btn = Button(wd_main, text='忘记密码', width=8, height=2, command=xg_pwd)
    xg_btn.pack()
    xg_btn.place(relx=0.72, rely=0.85)

    xg_btn = Button(wd_main, text='忘记密码', width=8, height=2, command=xg_pwd)
    xg_btn.pack()
    xg_btn.place(relx=0.72, rely=0.85)

    wd_lab = Label(wd_main, text='我的账户', font=('STHeitiSC-Light', 20), bg='orange', width=50, height=5)
    wd_lab.pack()
    wd_lab.place(relx=0.01, rely=0.05)

    if not open('db/users.ini', 'r', encoding='utf-8').read():
        def dr_command():
            def dr_cmd():
                uid = dr_entry.get().encode('utf-8')
                pwd = dr_pwd.get().encode('utf-8')
                sk.send(('user?'.encode('utf-8') + uid + '?'.encode('utf-8') + pwd).zfill(128))
                uok = int(sk.recv(1).decode('gbk'))
                if uok == 1 or uok == 0:
                    if uok == 1:
                        messagebox.showinfo('登入', '登入成功！')
                        user_name = sk.recv(256).decode('utf-8').strip('0')
                        users['text'] = '我的昵称：' + user_name
                        open('db/users.ini', 'w', encoding='utf-8').write(uid.decode('utf-8') + '?' + pwd.decode('utf-8'))

                    if uok == 0:
                        messagebox.showinfo('登入', '登入失败！密码错误！')
                elif uok == 2:
                    messagebox.showinfo('异常', '账号不存在！')

            dr_main = Tk()

            dr_main.title('账号登入')
            dr_main.geometry('400x150+200+200')

            users = Label(wd_main, font=('ComicSansMS', 35))
            users.pack()
            users.place(relx=0.01, rely=0.40)

            user_id = Label(dr_main, text='您的UID:')
            user_id.pack()
            user_id.place(x=0, y=6)

            dr_entry = Entry(dr_main, width=30)
            dr_entry.pack()
            dr_entry.place(x=75, y=5)

            user_pwd = Label(dr_main, text='您的密码:')
            user_pwd.pack()
            user_pwd.place(x=0, y=46)

            dr_pwd = Entry(dr_main, width=30, show='*')
            dr_pwd.pack()
            dr_pwd.place(x=75, y=45)

            dr_btn = Button(dr_main, width=15, height=3, text='登入', command=dr_cmd)
            dr_btn.pack()
            dr_btn.place(relx=0.32, rely=0.6)

            dr_main.mainloop()

        dr = Button(wd_main, text='登入', font=('STHeitiSC-Light', 18), width=10, height=6, command=dr_command)
        dr.pack()
        dr.place(relx=0.84, rely=0.05)
    else:
        def dc_cmd():
            with open('db/users.ini', 'w', encoding='utf-8') as user_dc:
                user_dc.write('')

        sk.send(('user?'.encode('utf-8') + open('db/users.ini', 'r', encoding='utf-8').read().encode('utf-8')).zfill(128))
        uok_bl = sk.recv(1).decode('gbk')
        if uok_bl == '1':
            user = Label(wd_main, text='我的昵称：' + sk.recv(256).decode('utf-8').strip('0'), font=('ComicSansMS', 35))
            user.pack()
            user.place(relx=0.01, rely=0.40)
        else:
            messagebox.showinfo('验证失败', '登录超时！')
            open('db/users.ini', 'w', encoding='utf-8').write('')

        dc = Button(wd_main, text='登出', font=('STHeitiSC-Light', 18), width=10, height=6, command=dc_cmd)
        dc.pack()
        dc.place(relx=0.84, rely=0.05)

    wd_main.mainloop()


def ku_command():
    ku_main = Tk()

    ku_main.title('库')
    ku_main.geometry('970x700+100+100')

    dir_dict = dict()
    dir_list = os.listdir('Application/')
    dir_list.remove('__init__.py')
    dir_list.remove('__pycache__')
    dic_okn = len(dir_list)
    dic_num = 0
    for i in dir_list:
        dir_dict[str(dic_num)] = i
        dic_num += 1

    del dic_num
    del dir_list

    ku_lab = list()

    end_string = '.py'

    for op in range(dic_okn):
        ku_lab.append(Label(ku_main,
                            text=str(op + 1) + '. ' + dir_dict[str(op)].strip(end_string) + '\n\n' + (
                                open(f'Application/{dir_dict[str(op)]}',
                                     'r', encoding='utf-8').readlines()[0]).strip(
                                '\n').strip('"""'), width=30, height=8, bg='green3'))

    x = y = 10
    for b in ku_lab:

        b.pack()
        b.place(x=x, y=y)

        x += 320
        if x >= 960:
            y += 180
            x = 10

    open_entry = Entry(ku_main, width=95)
    open_entry.pack()
    open_entry.place(relx=0.01, rely=0.90)

    open_ok = Button(ku_main, text='打开', width=8, command=lambda: importlib.import_module(
        f'Application.{dir_dict[str(int(open_entry.get()) - 1)].strip(end_string)}'))
    open_ok.pack()
    open_ok.place(relx=0.92, rely=0.905)

    ku_main.mainloop()


# 创建socket对象
sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建套接字对象 (tcp/流式协议)
# sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # 创建套接字对象 (udp协议)
time_sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
start_time = str(datetime.datetime.now())
start_time = int(start_time[11:13])
if start_time == 12:
    whc = 'Good noon! '
elif 12 < start_time <= 18:
    whc = 'Good afternoon! '
elif start_time > 18:
    whc = 'Good evening! '
elif 0 < start_time < 12:
    whc = 'Good morning! '
else:
    whc = 'I don\'t now time. '

ip = [open('db/server.ini', 'r', encoding='utf-8').read(), 8080]
sk.connect(tuple(ip))
time_sk.connect(tuple(ip))

window = Tk()

window.title('Cloud Start')
window.geometry('1000x700+0+0')

data = sk.recv(128).decode('utf-8')
if data == '//start//':
    messagebox.showinfo('start', whc + 'Any OK!')

sy = Label(window, bg='white', font=('ComicSansMS', 75), width=0)
sy.pack()
sy.place(x=110, y=10)


def get_time():
    while True:
        time_sk.send('time'.encode('utf-8').zfill(128))
        time = time_sk.recv(1024).decode('utf-8').strip('0').split('.')[0]
        sy['text'] = time


time_g = Thread(target=get_time)
time_g.start()

sz = Button(window, text='设置', font=('PingFangSC-Regular', 40), width=16, height=3, command=sz_command)
sz.pack()
sz.place(x=70, y=165)
yysd = Button(window, text='应用商店', font=('PingFangSC-Regular', 40), width=16, height=3, command=yysd_command)
yysd.pack()
yysd.place(x=550, y=165)
wd = Button(window, text='我的', font=('PingFangSC-Regular', 40), width=16, height=3, command=wd_command)
wd.pack()
wd.place(x=70, y=420)
ku = Button(window, text='库', font=('PingFangSC-Regular', 40), width=16, height=3, command=ku_command)
ku.pack()
ku.place(x=550, y=420)

gy = Label(window, text='copyright(c) @2023 CloudStart MIKIYOU', bg='white', font=('PingFangSC-Regular', 12), width=0)
gy.pack()
gy.place(x=380, y=675)

window.mainloop()
